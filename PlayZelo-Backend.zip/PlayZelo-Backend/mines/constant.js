module.exports = {
    RoundResult: {
        payout: 'payout',
        finish: 'finish',
        lost: 'lost',
        none: ''
    }
}